/**
 * 
 */
/**
 * @author A.Nohejlova
 *
 */
package cz.muni.fi.IA158.robot.tasks.runnable;